﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FBLibrary;
using System.Configuration;
using System.Windows.Forms;

namespace FizzBuzzConsole
{
    /// <summary>
    /// 
    /// </summary>
    public class FizzBuzz
    {
        /// <summary>
        /// This method requires question number as an argument. Question configuration is defined in the App.Config file
        ///Question1, Question3, Question4, Question5, Question6     
        /// </summary>
        /// <param name="args">command line args passed in - expected Question</param>
        static void Main(string[] args)
        {
            String question = "";
            
            if (args.Length > 0)
            {
                question = args[0];
            }

            if (String.IsNullOrEmpty(ConfigurationManager.AppSettings[question.ToLower()]))
            {
                MessageBox.Show("Please enter a valid key to run the application");
                return;
            }
                          
            string[] strValues = ConfigurationManager.AppSettings[question.ToLower()].Split(',');
            FizzBuzz fizzBuzz = new FizzBuzz();
            fizzBuzz.ProcessandPrint(question, strValues);            
        }

        /// <summary>
        /// Method parses the mapping data and uses FizzBuzz library to analyze the numbers
        /// in the range and generate the output
        /// </summary>
        /// <param name="pquestion">Question being passed in as argument</param>
        /// <param name="pstrValues">String mapping loaded from the config file</param>
        public void ProcessandPrint(string pquestion, string[] pstrValues)
        {
            FizzBuzzLib objFizBizzLib = new FizzBuzzLib();
            string strOutput = "";
            Console.WriteLine("Output for " + pquestion + " is:");
            if (pquestion.ToLower() == "Question6".ToLower() || pquestion.ToLower() == "Question8".ToLower())
            {
                //strOutput = objFizBizzLib.PrintDynamicText(strValue);
                int min, max;
                min = int.Parse(pstrValues[pstrValues.Length - 2]);
                max = int.Parse(pstrValues[pstrValues.Length - 1]);
                for (int i = min; i <= max; i++)
                {
                    strOutput = objFizBizzLib.PrintDynamicText(pstrValues, i);
                    Console.WriteLine(strOutput);
                }
            }
            else
            {
                int min, max;
                min = int.Parse(pstrValues[pstrValues.Length - 2]);
                max = int.Parse(pstrValues[pstrValues.Length - 1]);
                for (int i = min; i <= max; i++)
                {
                    strOutput = objFizBizzLib.PrintText(pstrValues, i);
                    Console.WriteLine(strOutput);
                }

                //strOutput = objFizBizzLib.PrintText(strValue);
                //Console.WriteLine("Output for " + question + " is:\n" + strOutput);  
            }
            Console.WriteLine("Press enter to quit from results...");
            Console.ReadLine();
        }

    }
}
