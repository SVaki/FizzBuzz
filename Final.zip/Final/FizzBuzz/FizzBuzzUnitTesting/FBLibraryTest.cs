﻿using System;
using FBLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FizzBuzzUnitTesting
{
    /// <summary>
    /// Unit test class to test all the methods FizzBuzz library - DLL referenced
    /// </summary>
    [TestClass]
    public class FBLibraryTest
    {
        FizzBuzzLib objFizBizzLib = new FizzBuzzLib();
        string[] stringDynamicValues = { "3=FOO", "5=BAR", "7=BAZZ", "11=BANANA", "1", "11" };
        string[] stringValues = { "Fizz", "Buzz", "3", "5", "1", "5" };

        /// <summary>
        /// Test invalid input values and null values
        /// </summary>
        [TestMethod]
        public void Test_StringArguments_Mappings()
        {
            //Arguments cannot be null or less than 4 values - 
            //required string and integer values, min and max range values
            if (stringValues == null)
                throw new ArgumentNullException("Mapping is null");

            else if (stringValues.Length < 4)
                throw new ArgumentOutOfRangeException("Need atleast 4 values to run the program");            
        }

        /// <summary>
        /// Test input parameters for dynamic config data
        /// </summary>
        [TestMethod]
        public void Test_DynamicStringArguments_Mappings()
        {
            //Arguments cannot be null or less than 3 values - 
            //required integer=string values, min and max range values
            if (stringDynamicValues == null)
                throw new ArgumentNullException("Mapping is null");

            else if (stringDynamicValues.Length < 3)
                throw new ArgumentOutOfRangeException("Need atleast 3 values to run the program");
        }

        /// <summary>
        /// Test the Print method in Fizz Buzz for static mapping data
        /// </summary>

        [TestMethod]
        public void Test_PrintText_Method()
        {            
            string actual = objFizBizzLib.PrintText(stringValues, 3);
            Assert.AreEqual("Fizz", actual, true, "Unit test failed for first scenrio");
        }

        /// <summary>
        /// Test the Print method for dynamic config data processed by Fizz Buzz
        /// </summary>
        [TestMethod]
        public void Test_PrintDynamicText_Method()
        {
                  
            int min, max;
            string strOutput = "";

            min = int.Parse(stringDynamicValues[stringDynamicValues.Length - 2]);
            max = int.Parse(stringDynamicValues[stringDynamicValues.Length - 1]);
            for (int i = min; i <= max; i++)
            {
                strOutput += objFizBizzLib.PrintDynamicText(stringDynamicValues, i);                
            }

            string expectedOutput = "12FOO4BARFOOBAZZ8FOOBARBANANA";
            Assert.AreEqual(expectedOutput, strOutput, true, "Unit test failed for Question6 - dynamic data");
        }
    }
}
