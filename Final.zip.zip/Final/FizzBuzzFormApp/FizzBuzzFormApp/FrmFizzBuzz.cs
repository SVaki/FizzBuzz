﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FBLibrary;

namespace FizzBuzzFormApp
{
    public partial class FrmFizzBuzz : Form
    {
        
        List<string> inputStrings = new List<string>();
        
        public FrmFizzBuzz()
        {
            InitializeComponent();
        }

        private void FrmFizzBuzz_Load(object sender, EventArgs e)
        {
            //Setup the mapping section to be readonly. Users will not be expected to edit this control
            listPattern.ReadOnly = true;
            listPattern.BackColor = System.Drawing.SystemColors.Window;

            //Create tooltips for all the key controls
            System.Windows.Forms.ToolTip txtNbrTip = new System.Windows.Forms.ToolTip();
            txtNbrTip.SetToolTip(txtNumber, "Enter divisble number to be checked");

            System.Windows.Forms.ToolTip txtDisplayTip = new System.Windows.Forms.ToolTip();
            txtDisplayTip.SetToolTip(txtDisplay, "Enter display value for numbers divisible by the number entered");

            System.Windows.Forms.ToolTip txtAddTip = new System.Windows.Forms.ToolTip();
            txtAddTip.SetToolTip(btnAdd, "Click to add to the display patterns");

            System.Windows.Forms.ToolTip txtMinRangeTip = new System.Windows.Forms.ToolTip();
            txtMinRangeTip.SetToolTip(txtMinRange, "Enter minimum for the range of numbers");

            System.Windows.Forms.ToolTip txtMaxRangeTip = new System.Windows.Forms.ToolTip();
            txtMaxRangeTip.SetToolTip(txtMaxRange, "Enter maximum for the range of numbers");
        }

        /// <summary>
        /// This method is executed on Add button click. Check for valid data in Number and
        /// Display input fields. If valid, adds them to the pattern list for analysis.
        /// Clear the data once added and focus on the number field for additional fields
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            txtNumber.Text.Trim();
            txtDisplay.Text.Trim();

            if (txtNumber.Text == "") 
            {
                MessageBox.Show("Please enter a number", "Enter data");
                return;                
            }
            else if (txtDisplay.Text == "")
            {
                MessageBox.Show("Please enter a display value", "Enter data");
                return;
            }
            int divNumber = Int32.Parse(txtNumber.Text);

            string configString = txtNumber.Text + "=" + txtDisplay.Text;
            inputStrings.Add(configString);
            listPattern.Text += (configString + " \r\n");
            txtNumber.Clear();
            txtDisplay.Clear();
            txtNumber.Focus();
        }

        /// <summary>
        /// Run button click executes this method. Clears the output list and start the analyis of data based on user selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRun_Click(object sender, EventArgs e)
        {
            listResults.Clear();
            inputStrings.Add(txtMinRange.Text);
            inputStrings.Add(txtMaxRange.Text);
            printDynamicValues();
        }
       
        /// <summary>
        /// Analyze the data based on the patterns added for the range of numbers.
        /// Output is populated in the results window while showing a progress bar.
        /// Uses FBLib dll - an external reference
        /// </summary>
        private void printDynamicValues()
        {
            FizzBuzzLib objFizBizzLib = new FizzBuzzLib();
            string strOutput = "";            
            string[] strValues = inputStrings.ToArray();
                int min, max;
                min = int.Parse(strValues[strValues.Length - 2]);
                max = int.Parse(strValues[strValues.Length - 1]);
                progressBar1.Maximum = max;
                progressBar1.Step = 1;
                progressBar1.Value = 0;
                for (int i = min; i <= max; i++)
                {
                    strOutput = objFizBizzLib.PrintDynamicText(strValues, i);
                    listResults.Items.Add(strOutput);
                    progressBar1.PerformStep();
                    if (chkBoxStream.Checked)
                        Application.DoEvents();
                }
            }

        private void chkBoxStream_CheckedChanged(object sender, EventArgs e)
        {
            if(chkBoxStream.Checked)
             Application.DoEvents();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            listResults.Clear();
            progressBar1.Value = 0;
        }

        
        }

    }
